<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Granting Type -15</label>
    <protected>false</protected>
    <values>
        <field>BJE_Account_No__c</field>
        <value xsi:type="xsd:string">52301100</value>
    </values>
    <values>
        <field>BJE_Cost_Center__c</field>
        <value xsi:type="xsd:string">Please fill Internal Order of users department</value>
    </values>
    <values>
        <field>BJE_Granting_Type__c</field>
        <value xsi:type="xsd:string">Werbekostenzuschüsse an Kunden</value>
    </values>
</CustomMetadata>
