<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>BJE image 0005</label>
    <protected>false</protected>
    <values>
        <field>BJE_Default_url__c</field>
        <value xsi:type="xsd:string">https://www.busch-jaeger.de/systeme/busch-freehomer-flex</value>
    </values>
    <values>
        <field>BJE_Image_Title__c</field>
        <value xsi:type="xsd:string">Busch-free@home flex_B2C_627x120_bje_2022_ok_V1.png</value>
    </values>
</CustomMetadata>
