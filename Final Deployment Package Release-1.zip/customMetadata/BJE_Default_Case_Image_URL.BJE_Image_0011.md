<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>BJE Image 0011</label>
    <protected>false</protected>
    <values>
        <field>BJE_Default_url__c</field>
        <value xsi:type="xsd:string">https://www.busch-jaeger.de/fuer-profis/service-tools/busch-baustellenplaner</value>
    </values>
    <values>
        <field>BJE_Image_Title__c</field>
        <value xsi:type="xsd:string">Busch_Baustellenplaner.jpg</value>
    </values>
</CustomMetadata>
