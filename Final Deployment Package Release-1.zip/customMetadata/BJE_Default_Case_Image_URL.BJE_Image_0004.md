<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>BJE Image 0004</label>
    <protected>false</protected>
    <values>
        <field>BJE_Default_url__c</field>
        <value xsi:type="xsd:string">https://www.busch-jaeger.de/busch-freeathome-flex</value>
    </values>
    <values>
        <field>BJE_Image_Title__c</field>
        <value xsi:type="xsd:string">Busch-flexTronics_B2B_627x120_bje_2022_ok.png</value>
    </values>
</CustomMetadata>
